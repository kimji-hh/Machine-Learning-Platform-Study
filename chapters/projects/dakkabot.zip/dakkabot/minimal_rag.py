import os

from langchain_community.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI

from index import GeminiEmbeddings

embeddings = GeminiEmbeddings()
vector_store = FAISS.load_local("DATA/faiss_index",
                                embeddings=embeddings,
                                allow_dangerous_deserialization=True)

retriever = vector_store.as_retriever()


llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.,
    google_api_key=os.environ["GEMINI_API_KEY"],
    convert_system_message_to_human=True
)


query = "How do I rotate encryption keys?"
docs = retriever.invoke(query)
context = "\n\n".join([doc.page_content for doc in docs])

prompt = f"""
Based on the following DataKrypt documentation, answer the question:

Context: {context}

Question: {query}

Answer:"""

response = llm.invoke(prompt)

print(response.content)