# DataKrypt Extended Documentation - Part 2

## Additional API Services

### analytics-service API Reference

**Base URL**: `https://api.datakrypt.com/analytics/v1`

##### POST /metrics
Submit custom metrics for analysis

**Request:**
```json
{
  "metric_name": "string",
  "value": 123.45,
  "timestamp": "2023-01-01T00:00:00Z",
  "tags": {
    "service": "auth-service",
    "environment": "production",
    "region": "us-east-1"
  },
  "metadata": {
    "user_id": "string",
    "request_id": "string"
  }
}
```

**Response:**
```json
{
  "metric_id": "string",
  "ingested_at": "2023-01-01T00:00:00Z",
  "status": "accepted|rejected",
  "validation_errors": []
}
```

##### GET /dashboards
Retrieve analytics dashboards

**Query Parameters:**
- `category`: "security|performance|business|compliance"
- `time_range`: "1h|24h|7d|30d|90d"
- `environment`: "dev|staging|prod"

**Response:**
```json
{
  "dashboards": [
    {
      "dashboard_id": "security_overview",
      "title": "Security Analytics Dashboard",
      "description": "Real-time security metrics and threat trends",
      "widgets": [
        {
          "widget_id": "threat_volume",
          "type": "time_series",
          "query": "threat_events{severity='high'}",
          "visualization": "line_chart"
        }
      ],
      "last_updated": "2023-01-01T00:00:00Z"
    }
  ]
}
```

##### POST /reports/generate
Generate analytics reports

**Request:**
```json
{
  "report_type": "security_summary|performance_analysis|user_activity|cost_analysis",
  "time_range": {
    "start": "2023-01-01T00:00:00Z",
    "end": "2023-01-31T23:59:59Z"
  },
  "filters": {
    "services": ["auth-service", "encryption-service"],
    "severity": ["medium", "high", "critical"],
    "users": ["admin", "analyst"]
  },
  "format": "pdf|json|csv|excel",
  "delivery": {
    "method": "email|download|webhook",
    "recipients": ["admin@datakrypt.com"]
  }
}
```

##### GET /anomalies
Detect anomalies in system behavior

**Query Parameters:**
- `service`: string filter
- `metric_type`: "performance|security|usage"
- `sensitivity`: "low|medium|high"
- `time_window`: "1h|6h|24h|7d"

**Response:**
```json
{
  "anomalies": [
    {
      "anomaly_id": "string",
      "metric_name": "api_response_time",
      "detected_at": "2023-01-01T00:00:00Z",
      "severity": "medium",
      "description": "Response time increased by 300% from baseline",
      "baseline_value": 150.0,
      "current_value": 450.0,
      "confidence_score": 0.87,
      "suggested_actions": [
        "Check database performance",
        "Review recent deployments",
        "Scale up service instances"
      ]
    }
  ]
}
```

### user-management-service API Reference

**Base URL**: `https://api.datakrypt.com/users/v1`

##### POST /users
Create new user account

**Request:**
```json
{
  "username": "string",
  "email": "string",
  "password": "string",
  "role": "admin|analyst|viewer|api_user",
  "profile": {
    "first_name": "string",
    "last_name": "string",
    "department": "string",
    "manager_id": "string"
  },
  "permissions": ["encrypt:data", "view:threats", "manage:users"],
  "account_settings": {
    "mfa_enabled": true,
    "password_expiry_days": 90,
    "session_timeout_minutes": 60
  }
}
```

**Response:**
```json
{
  "user_id": "string",
  "username": "string",
  "status": "active|pending_verification|suspended",
  "created_at": "2023-01-01T00:00:00Z",
  "verification_token": "string",
  "temporary_password": "string"
}
```

##### PUT /users/{user_id}/role
Update user role and permissions

**Request:**
```json
{
  "role": "admin|analyst|viewer|api_user",
  "permissions": ["string"],
  "effective_date": "2023-01-01T00:00:00Z",
  "reason": "Promotion to senior analyst role"
}
```

##### GET /users/{user_id}/activity
Get user activity history

**Query Parameters:**
- `start_date`: ISO 8601 timestamp
- `end_date`: ISO 8601 timestamp
- `activity_type`: "login|api_call|configuration_change|data_access"
- `limit`: integer (default: 100)

**Response:**
```json
{
  "activities": [
    {
      "activity_id": "string",
      "user_id": "string",
      "activity_type": "api_call",
      "timestamp": "2023-01-01T00:00:00Z",
      "details": {
        "endpoint": "/encryption/v1/encrypt",
        "method": "POST",
        "ip_address": "192.168.1.100",
        "user_agent": "DataKrypt-CLI/1.2.3",
        "status_code": 200
      },
      "risk_score": 0.1
    }
  ],
  "total_count": 1247,
  "next_page_token": "string"
}
```

##### POST /users/bulk-operations
Perform bulk operations on multiple users

**Request:**
```json
{
  "operation": "deactivate|activate|reset_password|update_role",
  "user_ids": ["string"],
  "parameters": {
    "new_role": "viewer",
    "send_notification": true,
    "effective_date": "2023-01-01T00:00:00Z"
  },
  "dry_run": false
}
```

### webhook-service API Reference

**Base URL**: `https://api.datakrypt.com/webhooks/v1`

##### POST /webhooks
Register new webhook endpoint

**Request:**
```json
{
  "url": "https://customer.example.com/datakrypt-webhook",
  "events": [
    "threat.detected",
    "key.rotated",
    "compliance.violation",
    "user.created"
  ],
  "filters": {
    "severity": ["high", "critical"],
    "services": ["threat-detection-service"]
  },
  "auth": {
    "type": "api_key|hmac|oauth2",
    "credentials": {
      "api_key": "customer_webhook_key_123"
    }
  },
  "retry_policy": {
    "max_attempts": 3,
    "backoff_strategy": "exponential",
    "timeout_seconds": 30
  }
}
```

**Response:**
```json
{
  "webhook_id": "string",
  "secret": "string",
  "status": "active",
  "created_at": "2023-01-01T00:00:00Z",
  "last_verified": "2023-01-01T00:00:00Z"
}
```

##### GET /webhooks/{webhook_id}/deliveries
Get webhook delivery history

**Query Parameters:**
- `start_date`: ISO 8601 timestamp
- `end_date`: ISO 8601 timestamp
- `status`: "success|failed|pending|retrying"
- `event_type`: string filter

**Response:**
```json
{
  "deliveries": [
    {
      "delivery_id": "string",
      "webhook_id": "string",
      "event_type": "threat.detected",
      "attempt_number": 1,
      "status": "success",
      "response_code": 200,
      "delivered_at": "2023-01-01T00:00:00Z",
      "response_time_ms": 245,
      "payload_size_bytes": 1024,
      "error_message": null
    }
  ]
}
```

##### POST /webhooks/{webhook_id}/test
Test webhook endpoint

**Request:**
```json
{
  "event_type": "test.ping",
  "custom_payload": {
    "test": true,
    "message": "Webhook configuration test"
  }
}
```

### rate-limiting-service API Reference

**Base URL**: `https://api.datakrypt.com/rate-limiting/v1`

##### POST /limits
Create or update rate limiting rules

**Request:**
```json
{
  "rule_name": "string",
  "scope": "user|ip|api_key|service",
  "identifier": "string",
  "limits": [
    {
      "window": "1m|5m|1h|1d",
      "max_requests": 100,
      "burst_limit": 20
    }
  ],
  "actions": [
    {
      "type": "throttle|block|alert",
      "duration": "5m",
      "notification_channels": ["slack", "email"]
    }
  ],
  "exemptions": ["admin_role", "monitoring_service"]
}
```

##### GET /limits/{scope}/{identifier}/status
Check current rate limit status

**Response:**
```json
{
  "scope": "user",
  "identifier": "user_123",
  "current_usage": {
    "1m": {
      "requests": 45,
      "limit": 100,
      "remaining": 55,
      "reset_time": "2023-01-01T00:01:00Z"
    },
    "1h": {
      "requests": 850,
      "limit": 1000,
      "remaining": 150,
      "reset_time": "2023-01-01T01:00:00Z"
    }
  },
  "status": "within_limits|throttled|blocked",
  "next_allowed_request": "2023-01-01T00:00:30Z"
}
```

##### POST /quotas
Manage API quotas for customers

**Request:**
```json
{
  "customer_id": "string",
  "service": "encryption|threat-detection|compliance",
  "quota_type": "requests|data_volume|compute_units",
  "limit": 1000000,
  "period": "monthly|daily|annual",
  "overage_policy": "block|charge|warn",
  "effective_date": "2023-01-01T00:00:00Z"
}
```

## Operational Documentation

### Service Mesh Configuration (Istio)

#### Traffic Management

**Virtual Service Configuration for auth-service:**

```yaml
apiVersion: networking.istio.io/v1beta1
kind: VirtualService
metadata:
  name: auth-service
  namespace: datakrypt
spec:
  hosts:
    - auth-service
  http:
    - match:
        - headers:
            user-type:
              exact: premium
      route:
        - destination:
            host: auth-service
            subset: v2
          weight: 100
    - route:
        - destination:
            host: auth-service
            subset: v1
          weight: 90
        - destination:
            host: auth-service
            subset: v2
          weight: 10
    - fault:
        delay:
          percentage:
            value: 0.1
          fixedDelay: 5s
    - timeout: 10s
      retries:
        attempts: 3
        perTryTimeout: 3s
```

**Destination Rule for Circuit Breaking:**

```yaml
apiVersion: networking.istio.io/v1beta1
kind: DestinationRule
metadata:
  name: encryption-service
  namespace: datakrypt
spec:
  host: encryption-service
  trafficPolicy:
    connectionPool:
      tcp:
        maxConnections: 100
      http:
        http1MaxPendingRequests: 50
        maxRequestsPerConnection: 10
    outlierDetection:
      consecutiveErrors: 3
      interval: 30s
      baseEjectionTime: 30s
      maxEjectionPercent: 50
  subsets:
    - name: v1
      labels:
        version: v1
    - name: v2
      labels:
        version: v2
```

#### Security Policies

**Authorization Policy for threat-detection-service:**

```yaml
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: threat-detection-authz
  namespace: datakrypt
spec:
  selector:
    matchLabels:
      app: threat-detection-service
  rules:
    - from:
        - source:
            principals: ["cluster.local/ns/datakrypt/sa/auth-service"]
        - source:
            principals: ["cluster.local/ns/datakrypt/sa/webhook-service"]
      to:
        - operation:
            methods: ["POST"]
            paths: ["/v1/analyze"]
    - from:
        - source:
            principals: ["cluster.local/ns/datakrypt/sa/analytics-service"]
      to:
        - operation:
            methods: ["GET"]
            paths: ["/v1/threats", "/v1/rules/*/stats"]
```

### GitOps Configuration (ArgoCD)

#### Application Definition

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: datakrypt-platform
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/datakrypt/platform-manifests
    targetRevision: HEAD
    path: kubernetes/overlays/production
  destination:
    server: https://kubernetes.default.svc
    namespace: datakrypt
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
      allowEmpty: false
    syncOptions:
      - CreateNamespace=true
      - PrunePropagationPolicy=foreground
      - PruneLast=true
    retry:
      limit: 5
      backoff:
        duration: 5s
        factor: 2
        maxDuration: 3m
```

#### Environment-Specific Configurations

**Production Values (values-prod.yaml):**

```yaml
global:
  environment: production
  region: us-east-1
  monitoring:
    enabled: true
    retention: 90d

auth-service:
  replicaCount: 5
  resources:
    limits:
      memory: 1Gi
      cpu: 1000m
    requests:
      memory: 512Mi
      cpu: 500m
  autoscaling:
    enabled: true
    minReplicas: 3
    maxReplicas: 10
    targetCPUUtilizationPercentage: 70

encryption-service:
  replicaCount: 3
  resources:
    limits:
      memory: 2Gi
      cpu: 2000m
    requests:
      memory: 1Gi
      cpu: 1000m
  hsm:
    enabled: true
    redundancy: true
    partition: production

threat-detection-service:
  replicaCount: 4
  resources:
    limits:
      memory: 4Gi
      cpu: 4000m
    requests:
      memory: 2Gi
      cpu: 2000m
  ml_models:
    enabled: true
    gpu_acceleration: true
```

**Staging Values (values-staging.yaml):**

```yaml
global:
  environment: staging
  region: us-west-2
  monitoring:
    enabled: true
    retention: 30d

auth-service:
  replicaCount: 2
  resources:
    limits:
      memory: 512Mi
      cpu: 500m
    requests:
      memory: 256Mi
      cpu: 250m
  autoscaling:
    enabled: false

encryption-service:
  replicaCount: 1
  resources:
    limits:
      memory: 1Gi
      cpu: 1000m
    requests:
      memory: 512Mi
      cpu: 500m
  hsm:
    enabled: false
    software_fallback: true
```

### Infrastructure as Code (Terraform)

#### VPC and Networking

```hcl
# vpc.tf
resource "aws_vpc" "datakrypt_vpc" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name        = "datakrypt-vpc-${var.environment}"
    Environment = var.environment
    Project     = "datakrypt"
  }
}

resource "aws_subnet" "private_subnets" {
  count             = length(var.availability_zones)
  vpc_id            = aws_vpc.datakrypt_vpc.id
  cidr_block        = "10.0.${count.index + 1}.0/24"
  availability_zone = var.availability_zones[count.index]

  tags = {
    Name = "datakrypt-private-subnet-${count.index + 1}"
    Type = "private"
    "kubernetes.io/role/internal-elb" = "1"
  }
}

resource "aws_subnet" "public_subnets" {
  count                   = length(var.availability_zones)
  vpc_id                  = aws_vpc.datakrypt_vpc.id
  cidr_block              = "10.0.${count.index + 10}.0/24"
  availability_zone       = var.availability_zones[count.index]
  map_public_ip_on_launch = true

  tags = {
    Name = "datakrypt-public-subnet-${count.index + 1}"
    Type = "public"
    "kubernetes.io/role/elb" = "1"
  }
}

# Security Groups
resource "aws_security_group" "eks_cluster" {
  name_prefix = "datakrypt-eks-cluster-"
  vpc_id      = aws_vpc.datakrypt_vpc.id

  ingress {
    from_port = 443
    to_port   = 443
    protocol  = "tcp"
    cidr_blocks = [aws_vpc.datakrypt_vpc.cidr_block]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "datakrypt-eks-cluster-sg"
  }
}
```

#### EKS Cluster Configuration

```hcl
# eks.tf
resource "aws_eks_cluster" "datakrypt" {
  name     = "datakrypt-${var.environment}"
  role_arn = aws_iam_role.eks_cluster.arn
  version  = "1.24"

  vpc_config {
    subnet_ids              = concat(aws_subnet.private_subnets[*].id, aws_subnet.public_subnets[*].id)
    endpoint_private_access = true
    endpoint_public_access  = true
    public_access_cidrs     = var.allowed_public_cidrs
    security_group_ids      = [aws_security_group.eks_cluster.id]
  }

  encryption_config {
    provider {
      key_arn = aws_kms_key.eks.arn
    }
    resources = ["secrets"]
  }

  enabled_cluster_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]

  depends_on = [
    aws_iam_role_policy_attachment.eks_cluster_policy,
    aws_iam_role_policy_attachment.eks_vpc_resource_controller,
  ]

  tags = {
    Environment = var.environment
    Project     = "datakrypt"
  }
}

resource "aws_eks_node_group" "datakrypt_nodes" {
  cluster_name    = aws_eks_cluster.datakrypt.name
  node_group_name = "datakrypt-nodes-${var.environment}"
  node_role_arn   = aws_iam_role.eks_node_group.arn
  subnet_ids      = aws_subnet.private_subnets[*].id

  capacity_type  = "ON_DEMAND"
  instance_types = ["t3.large", "t3.xlarge"]

  scaling_config {
    desired_size = var.node_desired_size
    max_size     = var.node_max_size
    min_size     = var.node_min_size
  }

  update_config {
    max_unavailable = 1
  }

  launch_template {
    id      = aws_launch_template.eks_nodes.id
    version = aws_launch_template.eks_nodes.latest_version
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_worker_node_policy,
    aws_iam_role_policy_attachment.eks_cni_policy,
    aws_iam_role_policy_attachment.eks_container_registry_policy,
  ]

  tags = {
    Environment = var.environment
    Project     = "datakrypt"
  }
}
```

#### RDS Configuration

```hcl
# rds.tf
resource "aws_db_subnet_group" "datakrypt" {
  name       = "datakrypt-db-subnet-group-${var.environment}"
  subnet_ids = aws_subnet.private_subnets[*].id

  tags = {
    Name = "DataKrypt DB subnet group"
  }
}

resource "aws_db_instance" "datakrypt_primary" {
  identifier             = "datakrypt-primary-${var.environment}"
  allocated_storage      = var.db_allocated_storage
  max_allocated_storage  = var.db_max_allocated_storage
  storage_type           = "gp3"
  storage_encrypted      = true
  kms_key_id            = aws_kms_key.rds.arn

  engine         = "postgres"
  engine_version = "14.9"
  instance_class = var.db_instance_class

  db_name  = "datakrypt"
  username = var.db_username
  password = var.db_password

  vpc_security_group_ids = [aws_security_group.rds.id]
  db_subnet_group_name   = aws_db_subnet_group.datakrypt.name

  backup_retention_period = var.environment == "production" ? 30 : 7
  backup_window          = "03:00-04:00"
  maintenance_window     = "sun:04:00-sun:05:00"

  skip_final_snapshot = var.environment != "production"
  deletion_protection = var.environment == "production"

  performance_insights_enabled = true
  monitoring_interval         = 60
  monitoring_role_arn        = aws_iam_role.rds_monitoring.arn

  tags = {
    Name        = "datakrypt-primary-${var.environment}"
    Environment = var.environment
  }
}

resource "aws_db_instance" "datakrypt_replica" {
  count = var.environment == "production" ? 2 : 0

  identifier = "datakrypt-replica-${count.index + 1}-${var.environment}"
  
  replicate_source_db = aws_db_instance.datakrypt_primary.id
  instance_class      = var.db_replica_instance_class
  
  auto_minor_version_upgrade = false
  skip_final_snapshot       = true

  tags = {
    Name        = "datakrypt-replica-${count.index + 1}-${var.environment}"
    Environment = var.environment
  }
}
```

### Disaster Recovery Procedures

#### Database Backup and Recovery

**Automated Backup Strategy:**

```bash
#!/bin/bash
# backup-database.sh

set -euo pipefail

# Configuration
BACKUP_BUCKET="datakrypt-backups-${ENVIRONMENT}"
DB_HOST="${DB_HOST:-datakrypt-primary-production.cluster-xxx.us-east-1.rds.amazonaws.com}"
DB_NAME="${DB_NAME:-datakrypt}"
DB_USER="${DB_USER:-backup_user}"
RETENTION_DAYS=90

# Create timestamp
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_FILE="datakrypt_backup_${TIMESTAMP}.sql"

# Create database dump
echo "Starting database backup at $(date)"
pg_dump \
  --host="${DB_HOST}" \
  --username="${DB_USER}" \
  --dbname="${DB_NAME}" \
  --no-password \
  --format=custom \
  --compress=9 \
  --file="${BACKUP_FILE}"

# Encrypt backup file
gpg --trust-model always \
    --recipient datakrypt-backup@datakrypt.com \
    --encrypt "${BACKUP_FILE}"

# Upload to S3
aws s3 cp "${BACKUP_FILE}.gpg" "s3://${BACKUP_BUCKET}/database/${BACKUP_FILE}.gpg"

# Verify upload
aws s3 ls "s3://${BACKUP_BUCKET}/database/${BACKUP_FILE}.gpg"

# Cleanup local files
rm "${BACKUP_FILE}" "${BACKUP_FILE}.gpg"

# Cleanup old backups
aws s3 ls "s3://${BACKUP_BUCKET}/database/" | \
  awk '$1 < "'$(date -d "${RETENTION_DAYS} days ago" '+%Y-%m-%d')'" {print $4}' | \
  xargs -I {} aws s3 rm "s3://${BACKUP_BUCKET}/database/{}"

echo "Database backup completed successfully"
```

**Recovery Procedure:**

```bash
#!/bin/bash
# restore-database.sh

set -euo pipefail

BACKUP_FILE="$1"
TARGET_DB="${2:-datakrypt_restore_$(date +%Y%m%d_%H%M%S)}"

if [ -z "$BACKUP_FILE" ]; then
  echo "Usage: $0 <backup_file> [target_database]"
  exit 1
fi

# Download backup from S3
aws s3 cp "s3://${BACKUP_BUCKET}/database/${BACKUP_FILE}" .

# Decrypt backup
gpg --decrypt "${BACKUP_FILE}" > "${BACKUP_FILE%.gpg}"

# Create target database
createdb --host="${DB_HOST}" --username="${DB_USER}" "${TARGET_DB}"

# Restore data
pg_restore \
  --host="${DB_HOST}" \
  --username="${DB_USER}" \
  --dbname="${TARGET_DB}" \
  --no-password \
  --clean \
  --if-exists \
  "${BACKUP_FILE%.gpg}"

echo "Database restored to ${TARGET_DB}"
```

#### Service Recovery Procedures

**Complete Platform Recovery:**

1. **Infrastructure Recovery (RTO: 30 minutes)**
   ```bash
   # Restore from Terraform state
   terraform init
   terraform plan -var-file="environments/production.tfvars"
   terraform apply -auto-approve
   
   # Verify EKS cluster
   aws eks update-kubeconfig --name datakrypt-production
   kubectl get nodes
   ```

2. **Database Recovery (RTO: 2 hours)**
   ```bash
   # Identify latest backup
   LATEST_BACKUP=$(aws s3 ls s3://datakrypt-backups-production/database/ | \
                   sort | tail -n 1 | awk '{print $4}')
   
   # Restore database
   ./restore-database.sh "$LATEST_BACKUP" datakrypt
   ```

3. **Application Recovery (RTO: 15 minutes)**
   ```bash
   # Deploy applications via ArgoCD
   kubectl apply -f argocd/applications/
   
   # Wait for all services to be healthy
   kubectl wait --for=condition=available --timeout=600s deployment --all -n datakrypt
   ```

4. **Data Validation (RTO: 30 minutes)**
   ```bash
   # Verify critical functionality
   ./scripts/validate-recovery.sh
   
   # Check data integrity
   kubectl exec -it deployment/compliance-service -- \
     python manage.py check_data_integrity
   ```

#### Business Continuity Plan

**Communication Tree:**
1. **Incident Commander**: CTO or designated senior engineer
2. **Technical Team**: Platform engineering team
3. **Business Stakeholders**: CEO, VP Engineering, Customer Success
4. **External**: Customers (via status page), Partners (via dedicated channel)

**Recovery Time Objectives (RTO):**
- **P0 Services**: 30 minutes
- **P1 Services**: 2 hours
- **P2 Services**: 8 hours
- **P3 Services**: 24 hours

**Recovery Point Objectives (RPO):**
- **Critical Data**: 15 minutes (continuous replication)
- **Application Data**: 1 hour (frequent backups)
- **Configuration Data**: 24 hours (daily backups)
- **Logs/Analytics**: 24 hours (acceptable data loss)

### Compliance Documentation

#### SOC 2 Type II Controls

**CC6.1 - Logical and Physical Access Controls**

*Control Description:* The entity implements logical access security measures to protect against threats from sources outside its system boundaries.

*Control Activities:*
1. Multi-factor authentication required for all administrative access
2. Role-based access control (RBAC) implemented across all services
3. Regular access reviews conducted quarterly
4. Privileged access managed through just-in-time (JIT) access

*Evidence:*
- IAM policies and role definitions
- MFA enforcement logs
- Quarterly access review reports
- JIT access audit trails

*Testing Procedures:*
- Verify MFA is enforced for all admin accounts
- Review RBAC configurations for principle of least privilege
- Test access controls with simulated breach scenarios
- Validate access review process completeness

**CC6.2 - Prior to Issuing System Credentials**

*Control Description:* Prior to issuing system credentials and granting system access, the entity registers and authorizes new internal and external users.

*Control Activities:*
1. Background checks required for all employees with system access
2. Manager approval required for all access requests
3. Automated provisioning workflow with approval gates
4. New user security training completion before access granted

*Evidence:*
- HR background check records
- Access request approval workflows
- Training completion certificates
- User provisioning audit logs

#### GDPR Compliance Framework

**Data Processing Activities:**

1. **User Authentication Data**
    - *Purpose:* User identification and access control
    - *Legal Basis:* Legitimate interest (security)
    - *Retention:* 7 years after account deletion
    - *Transfers:* None outside EU

2. **Audit Logs**
    - *Purpose:* Security monitoring and compliance
    - *Legal Basis:* Legal obligation (regulatory requirements)
    - *Retention:* 7 years as required by regulations
    - *Transfers:* Encrypted transfer to US-based analysis systems

3. **Threat Detection Data**
    - *Purpose:* Cybersecurity and fraud prevention
    - *Legal Basis:* Legitimate interest (security)
    - *Retention:* 2 years for analysis, 7 years for incidents
    - *Transfers:* Real-time processing in multiple regions

**Data Subject Rights Implementation:**

```python
# gdpr_compliance.py
class GDPRComplianceService:
    """
    Service for handling GDPR data subject rights requests
    """
    
    def process_data_access_request(self, user_id: str, request_id: str):
        """
        Article 15 - Right of access by the data subject
        Compile all personal data for a given user
        """
        user_data = {
            'profile': self.get_user_profile(user_id),
            'activity_logs': self.get_user_activity(user_id),
            'audit_trail': self.get_audit_trail(user_id),
            'encrypted_data': self.get_encrypted_data_references(user_id)
        }
        
        # Create portable data export
        export_file = self.create_data_export(user_data, format='json')
        
        # Log the access request
        self.log_gdpr_request(user_id, 'data_access', request_id)
        
        return export_file
    
    def process_data_deletion_request(self, user_id: str, request_id: str):
        """
        Article 17 - Right to erasure ('right to be forgotten')
        """
        # Verify deletion is legally permissible
        if self.has_legal_retention_requirement(user_id):
            raise GDPRException("Cannot delete: legal retention requirements apply")
        
        deletion_plan = {
            'user_profile': 'immediate_deletion',
            'activity_logs': 'anonymization',
            'audit_trail': 'retain_for_compliance',
            'backups': 'schedule_for_deletion'
        }
        
        # Execute deletion plan
        for data_type, action in deletion_plan.items():
            if action == 'immediate_deletion':
                self.delete_data(user_id, data_type)
            elif action == 'anonymization':
                self.anonymize_data(user_id, data_type)
        
        # Log the deletion request
        self.log_gdpr_request(user_id, 'data_deletion', request_id)
        
        return deletion_plan
    
    def process_data_portability_request(self, user_id: str, target_format: str):
        """
        Article 20 - Right to data portability
        """
        portable_data = self.extract_portable_data(user_id)
        
        if target_format == 'json':
            return self.format_as_json(portable_data)
        elif target_format == 'csv':
            return self.format_as_csv(portable_data)
        elif target_format == 'xml':
            return self.format_as_xml(portable_data)
        
        raise ValueError(f"Unsupported format: {target_format}")
```

**Data Retention Policies:**

| Data Category | Retention Period | Legal Basis | Deletion Method |
|---------------|------------------|-------------|-----------------|
| User profiles | 30 days after account closure | Contract fulfillment | Secure deletion |
| Authentication logs | 7 years | Legal obligation | Automated purge |
| Financial records | 7 years | Legal obligation | Secure archival |
| Security incidents | 7 years | Legitimate interest | Encrypted storage |
| Marketing data | Until consent withdrawn | Consent | Immediate deletion |

#### PCI DSS Compliance

**Requirement 3: Protect stored cardholder data**

*Implementation:*
- All payment data encrypted using AES-256-GCM
- Encryption keys managed through dedicated HSM
- Key rotation performed every 90 days
- No storage of sensitive authentication data (CVV, PIN)

*Evidence:*
- Encryption implementation documentation
- HSM configuration and audit logs
- Key rotation procedures and schedules
- Data flow diagrams showing cardholder data handling

**Requirement 6: Develop and maintain secure systems**

*Implementation:*
- Secure coding standards enforced through automated scanning
- Regular vulnerability assessments and penetration testing
- Change management process for all system modifications
- Separate development, testing, and production environments

*Evidence:*
- Code review reports and security scan results
- Penetration testing reports (quarterly)
- Change management approval workflows
- Environment segregation documentation

## Advanced Monitoring and Observability

### Distributed Tracing Configuration

#### Jaeger Setup for Microservices

**Jaeger Operator Configuration:**

```yaml
# jaeger-production.yaml
apiVersion: jaegertracing.io/v1
kind: Jaeger
metadata:
  name: datakrypt-tracing
  namespace: observability
spec:
  strategy: production
  storage:
    type: elasticsearch
    elasticsearch:
      nodeCount: 3
      storage:
        storageClass: gp3
        size: 100Gi
      redundancyPolicy: SingleRedundancy
  collector:
    maxReplicas: 10
    resources:
      limits:
        memory: 1Gi
        cpu: 1000m
  query:
    replicas: 3
    resources:
      limits:
        memory: 512Mi
        cpu: 500m
  agent:
    strategy: DaemonSet
    resources:
      limits:
        memory: 256Mi
        cpu: 250m
```

**Service Instrumentation Example:**

```python
# tracing_middleware.py
from opentelemetry import trace
from opentelemetry.exporter.jaeger.thrift import JaegerExporter
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.instrumentation.requests import RequestsInstrumentor
from opentelemetry.instrumentation.flask import FlaskInstrumentor

def setup_tracing(service_name: str):
    """Initialize distributed tracing for a service"""
    
    # Set up tracer provider
    trace.set_tracer_provider(TracerProvider())
    tracer = trace.get_tracer(__name__)
    
    # Configure Jaeger exporter
    jaeger_exporter = JaegerExporter(
        agent_host_name=os.getenv("JAEGER_AGENT_HOST", "localhost"),
        agent_port=int(os.getenv("JAEGER_AGENT_PORT", "6831")),
    )
    
    # Add span processor
    span_processor = BatchSpanProcessor(jaeger_exporter)
    trace.get_tracer_provider().add_span_processor(span_processor)
    
    # Auto-instrument common libraries
    RequestsInstrumentor().instrument()
    FlaskInstrumentor().instrument_app(app)
    
    return tracer

# Usage in auth-service
@app.route('/login', methods=['POST'])
def login():
    tracer = trace.get_tracer(__name__)
    
    with tracer.start_as_current_span("user_authentication") as span:
        span.set_attribute("user.id", user_id)
        span.set_attribute("auth.method", "password")
        
        # Validate credentials
        with tracer.start_as_current_span("credential_validation"):
            is_valid = validate_credentials(username, password)
            span.set_attribute("auth.valid", is_valid)
        
        if is_valid:
            # Generate JWT token
            with tracer.start_as_current_span("token_generation"):
                token = generate_jwt_token(user_id)
                span.set_attribute("token.type", "jwt")
                span.set_attribute("token.expires_in", 3600)
            
            return {"access_token": token}
        else:
            span.set_attribute("error", True)
            span.set_attribute("error.type", "authentication_failed")
            return {"error": "Invalid credentials"}, 401
```

### Custom Metrics and Alerting

#### Prometheus Custom Metrics

```python
# metrics.py
from prometheus_client import Counter, Histogram, Gauge, start_http_server
import time

# Business metrics
encryption_operations_total = Counter(
    'datakrypt_encryption_operations_total',
    'Total number of encryption operations',
    ['service', 'operation', 'algorithm']
)

threat_detections_total = Counter(
    'datakrypt_threat_detections_total', 
    'Total number of threats detected',
    ['severity', 'threat_type', 'source']
)

api_request_duration_seconds = Histogram(
    'datakrypt_api_request_duration_seconds',
    'API request duration in seconds',
    ['service', 'endpoint', 'method', 'status_code']
)

active_user_sessions = Gauge(
    'datakrypt_active_user_sessions',
    'Number of active user sessions',
    ['service']
)

# Security metrics
failed_authentication_attempts = Counter(
    'datakrypt_failed_auth_attempts_total',
    'Failed authentication attempts',
    ['source_ip', 'username', 'reason']
)

hsm_operations_total = Counter(
    'datakrypt_hsm_operations_total',
    'HSM operations performed',
    ['operation', 'partition', 'status']
)

compliance_violations_total = Counter(
    'datakrypt_compliance_violations_total',
    'Compliance violations detected',
    ['framework', 'control', 'severity']
)

# Usage tracking
class MetricsMiddleware:
    """Middleware to automatically track API metrics"""
    
    def __init__(self, app):
        self.app = app
    
    def __call__(self, environ, start_response):
        start_time = time.time()
        
        def new_start_response(status, response_headers, exc_info=None):
            # Record metrics after response
            duration = time.time() - start_time
            status_code = status.split()[0]
            
            api_request_duration_seconds.labels(
                service=environ.get('SERVICE_NAME', 'unknown'),
                endpoint=environ.get('PATH_INFO', '/'),
                method=environ.get('REQUEST_METHOD', 'GET'),
                status_code=status_code
            ).observe(duration)
            
            return start_response(status, response_headers, exc_info)
        
        return self.app(environ, new_start_response)
```

#### AlertManager Configuration

```yaml
# alertmanager.yml
global:
  smtp_smarthost: 'smtp.datakrypt.com:587'
  smtp_from: 'alerts@datakrypt.com'
  slack_api_url: 'https://hooks.slack.com/services/...'

route:
  group_by: ['alertname', 'cluster', 'service']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'web.hook'
  routes:
  - match:
      severity: critical
    receiver: 'critical-alerts'
  - match:
      severity: warning
    receiver: 'warning-alerts'
  - match:
      alertname: 'SecurityIncident'
    receiver: 'security-team'

receivers:
- name: 'web.hook'
  webhook_configs:
  - url: 'http://webhook-service:8006/v1/alerts'

- name: 'critical-alerts'
  slack_configs:
  - channel: '#incidents'
    title: 'Critical Alert: {{ .GroupLabels.alertname }}'
    text: '{{ range .Alerts }}{{ .Annotations.description }}{{ end }}'
    send_resolved: true
  pagerduty_configs:
  - service_key: 'your-pagerduty-service-key'

- name: 'security-team'
  email_configs:
  - to: 'security@datakrypt.com'
    subject: 'SECURITY ALERT: {{ .GroupLabels.alertname }}'
    body: |
      Alert: {{ .GroupLabels.alertname }}
      Severity: {{ .CommonLabels.severity }}
      Time: {{ .CommonAnnotations.timestamp }}
      
      Details:
      {{ range .Alerts }}
      - {{ .Annotations.description }}
      {{ end }}
```

### Log Aggregation and Analysis

#### ELK Stack Configuration

**Elasticsearch Index Templates:**

```json
{
  "index_patterns": ["datakrypt-logs-*"],
  "template": {
    "settings": {
      "number_of_shards": 3,
      "number_of_replicas": 1,
      "index.lifecycle.name": "datakrypt-logs-policy",
      "index.lifecycle.rollover_alias": "datakrypt-logs"
    },
    "mappings": {
      "properties": {
        "@timestamp": {"type": "date"},
        "service": {"type": "keyword"},
        "level": {"type": "keyword"},
        "message": {"type": "text"},
        "user_id": {"type": "keyword"},
        "request_id": {"type": "keyword"},
        "trace_id": {"type": "keyword"},
        "span_id": {"type": "keyword"},
        "source_ip": {"type": "ip"},
        "endpoint": {"type": "keyword"},
        "duration_ms": {"type": "integer"},
        "status_code": {"type": "integer"},
        "error": {
          "properties": {
            "type": {"type": "keyword"},
            "message": {"type": "text"},
            "stack_trace": {"type": "text"}
          }
        }
      }
    }
  }
}
```

**Logstash Pipeline Configuration:**

```ruby
# logstash.conf
input {
  beats {
    port => 5044
  }
}

filter {
  # Parse JSON logs
  if [fields][service] {
    mutate {
      add_field => { "service" => "%{[fields][service]}" }
    }
  }
  
  json {
    source => "message"
  }
  
  # Extract request ID from headers or generate one
  if ![request_id] {
    uuid {
      target => "request_id"
    }
  }
  
  # Parse user agent
  if [user_agent] {
    useragent {
      source => "user_agent"
      target => "ua"
    }
  }
  
  # GeoIP lookup for source IPs
  if [source_ip] {
    geoip {
      source => "source_ip"
      target => "geoip"
    }
  }
  
  # Security analysis
  if [level] == "ERROR" and [message] =~ /authentication failed/ {
    mutate {
      add_tag => ["security_event", "auth_failure"]
    }
  }
  
  if [message] =~ /(?i)(sql injection|xss|csrf)/ {
    mutate {
      add_tag => ["security_event", "attack_attempt"]
    }
  }
}

output {
  elasticsearch {
    hosts => ["elasticsearch:9200"]
    index => "datakrypt-logs-%{+YYYY.MM.dd}"
  }
  
  # Send security events to separate index
  if "security_event" in [tags] {
    elasticsearch {
      hosts => ["elasticsearch:9200"]
      index => "datakrypt-security-%{+YYYY.MM.dd}"
    }
  }
}
```

**Kibana Dashboard Configuration:**

```json
{
  "objects": [
    {
      "type": "dashboard",
      "id": "datakrypt-overview",
      "attributes": {
        "title": "DataKrypt Platform Overview",
        "panelsJSON": "[{\"panelIndex\":\"1\",\"gridData\":{\"x\":0,\"y\":0,\"w\":24,\"h\":15},\"embeddableConfig\":{},\"id\":\"service-health-status\"}]",
        "visualizations": [
          {
            "title": "Service Health Status",
            "visState": {
              "type": "metric",
              "params": {
                "metric": {
                  "colorSchema": "Green to Red",
                  "metricColorMode": "Background",
                  "useRanges": true,
                  "ranges": [
                    {"from": 0, "to": 95, "color": "rgb(165,0,38)"},
                    {"from": 95, "to": 99, "color": "rgb(255,255,190)"},
                    {"from": 99, "to": 100, "color": "rgb(0,104,55)"}
                  ]
                }
              }
            },
            "aggs": [
              {
                "id": "1",
                "type": "avg",
                "schema": "metric",
                "params": {
                  "field": "uptime_percentage"
                }
              }
            ]
          }
        ]
      }
    }
  ]
}
```
