# DataKrypt Developer Documentation Dataset

## Company Overview
**DataKrypt** is a cybersecurity platform specializing in data encryption, threat detection, and compliance automation. Founded in 2019, DataKrypt serves enterprise clients with a microservices-based architecture deployed on Kubernetes.

## Architecture Overview

### Core Services
- **auth-service** (Port 8001) - Authentication & Authorization
- **encryption-service** (Port 8002) - Data Encryption/Decryption
- **threat-detection-service** (Port 8003) - Anomaly Detection & Threat Analysis
- **compliance-service** (Port 8004) - Audit Trails & Reporting
- **key-management-service** (Port 8005) - Cryptographic Key Lifecycle

### Infrastructure
- **Kubernetes Cluster**: 3 environments (dev, staging, prod)
- **Database**: PostgreSQL with encrypted storage
- **Message Queue**: Redis for real-time threat processing
- **Monitoring**: Prometheus + Grafana
- **Log Management**: ELK Stack

---

## Documentation Structure

### 1. API Documentation

#### auth-service API Reference

**Base URL**: `https://api.datakrypt.com/auth/v1`

**Authentication**: All requests require Bearer token in Authorization header

##### POST /login
Authenticate user and return JWT token

**Request:**
```json
{
  "username": "string",
  "password": "string",
  "mfa_token": "string (optional)"
}
```

**Response:**
```json
{
  "access_token": "string",
  "refresh_token": "string",
  "expires_in": 3600,
  "user": {
    "id": "string",
    "username": "string",
    "role": "admin|analyst|viewer",
    "permissions": ["string"]
  }
}
```

**Error Codes:**
- `401`: Invalid credentials
- `403`: Account locked (too many failed attempts)
- `422`: MFA required but not provided

##### POST /refresh
Refresh expired access token

**Request:**
```json
{
  "refresh_token": "string"
}
```

##### GET /user/profile
Get current user profile information

**Headers:**
- `Authorization: Bearer <token>`

**Response:**
```json
{
  "id": "string",
  "username": "string",
  "email": "string",
  "role": "string",
  "created_at": "2023-01-01T00:00:00Z",
  "last_login": "2023-01-01T00:00:00Z",
  "permissions": ["encrypt:data", "decrypt:data", "view:threats"]
}
```

##### POST /api-keys
Generate new API key for service-to-service authentication

**Request:**
```json
{
  "name": "string",
  "permissions": ["string"],
  "expires_at": "2024-01-01T00:00:00Z (optional)"
}
```

**Response:**
```json
{
  "api_key": "dk_live_abc123...",
  "key_id": "string",
  "created_at": "2023-01-01T00:00:00Z"
}
```

#### encryption-service API Reference

**Base URL**: `https://api.datakrypt.com/encryption/v1`

##### POST /encrypt
Encrypt data using specified algorithm

**Request:**
```json
{
  "data": "string or base64",
  "algorithm": "AES-256-GCM|ChaCha20-Poly1305",
  "key_id": "string (optional, uses default if not provided)",
  "metadata": {
    "description": "string",
    "tags": ["string"]
  }
}
```

**Response:**
```json
{
  "encrypted_data": "base64_encoded_string",
  "encryption_key_id": "string",
  "algorithm": "string",
  "nonce": "base64_encoded_string",
  "created_at": "2023-01-01T00:00:00Z"
}
```

##### POST /decrypt
Decrypt previously encrypted data

**Request:**
```json
{
  "encrypted_data": "base64_encoded_string",
  "encryption_key_id": "string",
  "nonce": "base64_encoded_string"
}
```

**Response:**
```json
{
  "decrypted_data": "string",
  "decrypted_at": "2023-01-01T00:00:00Z"
}
```

##### GET /keys
List available encryption keys

**Query Parameters:**
- `active_only`: boolean (default: true)
- `algorithm`: string filter
- `limit`: integer (default: 50)

**Response:**
```json
{
  "keys": [
    {
      "key_id": "string",
      "algorithm": "string",
      "created_at": "2023-01-01T00:00:00Z",
      "status": "active|rotating|deprecated",
      "usage_count": 1234
    }
  ]
}
```

#### threat-detection-service API Reference

**Base URL**: `https://api.datakrypt.com/threats/v1`

##### POST /analyze
Submit data for threat analysis

**Request:**
```json
{
  "data": {
    "user_id": "string",
    "action": "string",
    "timestamp": "2023-01-01T00:00:00Z",
    "ip_address": "string",
    "user_agent": "string",
    "additional_context": {}
  },
  "analysis_type": "real-time|batch",
  "severity_threshold": "low|medium|high|critical"
}
```

**Response:**
```json
{
  "analysis_id": "string",
  "threat_score": 0.85,
  "severity": "high",
  "detected_threats": [
    {
      "type": "brute_force_attack",
      "confidence": 0.92,
      "description": "Multiple failed login attempts detected"
    }
  ],
  "recommendations": [
    "Block IP address temporarily",
    "Require MFA for this user"
  ],
  "analyzed_at": "2023-01-01T00:00:00Z"
}
```

##### GET /threats
Retrieve threat analysis results

**Query Parameters:**
- `start_date`: ISO 8601 timestamp
- `end_date`: ISO 8601 timestamp
- `severity`: string filter
- `status`: "open|investigating|resolved"

##### POST /rules
Create custom threat detection rule

**Request:**
```json
{
  "name": "string",
  "description": "string",
  "conditions": [
    {
      "field": "ip_address",
      "operator": "in",
      "value": ["192.168.1.0/24"]
    }
  ],
  "actions": [
    {
      "type": "block",
      "duration": "1h"
    }
  ],
  "severity": "medium"
}
```

##### GET /rules/{rule_id}/stats
Get statistics for a specific threat detection rule

**Response:**
```json
{
  "rule_id": "string",
  "triggered_count": 42,
  "last_triggered": "2023-01-01T00:00:00Z",
  "false_positive_rate": 0.05,
  "effectiveness_score": 0.87
}
```

#### compliance-service API Reference

**Base URL**: `https://api.datakrypt.com/compliance/v1`

##### GET /reports
Generate compliance reports

**Query Parameters:**
- `report_type`: "SOC2|GDPR|HIPAA|PCI_DSS"
- `start_date`: ISO 8601 timestamp
- `end_date`: ISO 8601 timestamp
- `format`: "json|pdf|csv"

**Response:**
```json
{
  "report_id": "string",
  "report_type": "SOC2",
  "generated_at": "2023-01-01T00:00:00Z",
  "compliance_score": 0.96,
  "findings": [
    {
      "control_id": "CC6.1",
      "status": "compliant",
      "evidence_count": 15,
      "last_verified": "2023-01-01T00:00:00Z"
    }
  ],
  "download_url": "https://api.datakrypt.com/compliance/v1/reports/abc123/download"
}
```

##### POST /audit-logs
Submit audit log entry

**Request:**
```json
{
  "event_type": "data_access|configuration_change|user_action",
  "user_id": "string",
  "resource": "string",
  "action": "string",
  "timestamp": "2023-01-01T00:00:00Z",
  "ip_address": "string",
  "user_agent": "string",
  "additional_metadata": {}
}
```

##### GET /controls
List compliance controls and their status

**Query Parameters:**
- `framework`: "SOC2|GDPR|HIPAA|PCI_DSS"
- `status`: "compliant|non_compliant|not_applicable"

**Response:**
```json
{
  "controls": [
    {
      "control_id": "CC6.1",
      "title": "Logical and Physical Access Controls",
      "description": "The entity implements logical access security measures...",
      "status": "compliant",
      "last_assessed": "2023-01-01T00:00:00Z",
      "next_assessment": "2023-04-01T00:00:00Z",
      "evidence_items": 12
    }
  ]
}
```

#### key-management-service API Reference

**Base URL**: `https://api.datakrypt.com/keys/v1`

##### POST /generate
Generate new encryption key

**Request:**
```json
{
  "algorithm": "AES-256-GCM|ChaCha20-Poly1305|RSA-4096",
  "purpose": "data_encryption|signing|key_wrapping",
  "metadata": {
    "description": "string",
    "owner": "string",
    "environment": "dev|staging|prod"
  }
}
```

**Response:**
```json
{
  "key_id": "string",
  "algorithm": "AES-256-GCM",
  "created_at": "2023-01-01T00:00:00Z",
  "status": "active",
  "public_key": "base64_encoded (for asymmetric keys only)"
}
```

##### POST /rotate/{key_id}
Initiate key rotation process

**Request:**
```json
{
  "rotation_strategy": "immediate|gradual",
  "notification_webhook": "https://webhook.example.com/key-rotated"
}
```

**Response:**
```json
{
  "rotation_id": "string",
  "old_key_id": "string",
  "new_key_id": "string",
  "status": "in_progress",
  "estimated_completion": "2023-01-01T01:00:00Z"
}
```

##### GET /hsm/status
Check Hardware Security Module status

**Response:**
```json
{
  "hsm_id": "string",
  "status": "healthy|degraded|offline",
  "last_health_check": "2023-01-01T00:00:00Z",
  "active_partitions": 2,
  "total_partitions": 4,
  "performance_metrics": {
    "operations_per_second": 1250,
    "average_latency_ms": 15
  }
}
```

#### notification-service API Reference

**Base URL**: `https://api.datakrypt.com/notifications/v1`

##### POST /send
Send notification to users or channels

**Request:**
```json
{
  "recipients": [
    {
      "type": "user|email|slack|webhook",
      "address": "user_id or email or channel_id or url"
    }
  ],
  "message": {
    "title": "string",
    "body": "string",
    "priority": "low|normal|high|urgent",
    "category": "security|system|maintenance|alert"
  },
  "delivery_options": {
    "retry_count": 3,
    "retry_delay": "5m"
  }
}
```

**Response:**
```json
{
  "notification_id": "string",
  "status": "queued|sent|failed",
  "delivered_count": 3,
  "failed_count": 0,
  "created_at": "2023-01-01T00:00:00Z"
}
```

##### GET /templates
List available notification templates

**Response:**
```json
{
  "templates": [
    {
      "template_id": "security_alert",
      "name": "Security Alert Template",
      "category": "security",
      "variables": ["alert_type", "severity", "description"],
      "channels": ["email", "slack"]
    }
  ]
}
```

##### POST /preferences
Update user notification preferences

**Request:**
```json
{
  "user_id": "string",
  "preferences": {
    "email_enabled": true,
    "slack_enabled": false,
    "quiet_hours": {
      "start": "22:00",
      "end": "06:00",
      "timezone": "UTC"
    },
    "categories": {
      "security": "immediate",
      "system": "daily_digest",
      "maintenance": "disabled"
    }
  }
}
```

#### backup-service API Reference

**Base URL**: `https://api.datakrypt.com/backup/v1`

##### POST /backup
Create backup of specified resources

**Request:**
```json
{
  "resources": [
    {
      "type": "database|files|configuration",
      "identifier": "string",
      "encryption_key_id": "string"
    }
  ],
  "backup_type": "full|incremental|differential",
  "retention_policy": "7d|30d|1y|permanent",
  "storage_location": "s3|azure|gcp"
}
```

**Response:**
```json
{
  "backup_id": "string",
  "status": "in_progress",
  "started_at": "2023-01-01T00:00:00Z",
  "estimated_completion": "2023-01-01T02:00:00Z",
  "backup_size_estimate": "15GB"
}
```

##### GET /backups/{backup_id}/verify
Verify backup integrity

**Response:**
```json
{
  "backup_id": "string",
  "verification_status": "valid|corrupted|missing",
  "verified_at": "2023-01-01T00:00:00Z",
  "checksum": "sha256_hash",
  "file_count": 1247,
  "total_size": "14.8GB"
}
```

##### POST /restore
Restore from backup

**Request:**
```json
{
  "backup_id": "string",
  "restore_target": "string",
  "restore_options": {
    "overwrite_existing": false,
    "restore_permissions": true,
    "point_in_time": "2023-01-01T00:00:00Z"
  }
}
```

### 6. Architecture Decision Records (ADRs)

#### ADR-001: Choice of Kubernetes for Container Orchestration

**Date:** 2023-03-15
**Status:** Accepted
**Context:**

DataKrypt needed a container orchestration platform to manage our microservices architecture. We evaluated three options:
1. Docker Swarm - Simple but limited scaling capabilities
2. Amazon ECS - AWS-specific, vendor lock-in concerns
3. Kubernetes - Industry standard, extensive ecosystem

**Decision:**
We chose Kubernetes for the following reasons:
- **Portability**: Can run on any cloud provider or on-premises
- **Ecosystem**: Rich ecosystem of tools (Helm, Istio, monitoring solutions)
- **Scalability**: Excellent horizontal and vertical scaling capabilities
- **Community**: Large community and extensive documentation

**Consequences:**
- **Positive**: Flexible deployment options, excellent tooling support
- **Negative**: Steeper learning curve, more complex initial setup
- **Neutral**: Industry standard choice, good for hiring

**Implementation Notes:**
- Started with managed Kubernetes (EKS) to reduce operational overhead
- Used Helm charts for standardized deployments
- Implemented GitOps with ArgoCD for deployment automation

#### ADR-002: PostgreSQL as Primary Database

**Date:** 2023-02-10
**Status:** Accepted
**Context:**

We needed a reliable database solution for storing user data, audit logs, and configuration. Evaluated options:
1. MongoDB - Document-based, flexible schema
2. MySQL - Popular relational database
3. PostgreSQL - Advanced relational database with JSON support

**Decision:**
PostgreSQL was selected because:
- **ACID compliance**: Critical for financial and security data
- **JSON support**: Flexibility for evolving schemas
- **Extensions**: Rich ecosystem (PostGIS, pgcrypto, etc.)
- **Performance**: Excellent query optimization and indexing

**Consequences:**
- **Positive**: Robust data consistency, excellent tooling
- **Negative**: Requires more database expertise than NoSQL
- **Risk Mitigation**: Implemented read replicas and automated backups

#### ADR-003: Event-Driven Architecture with Redis

**Date:** 2023-04-20
**Status:** Accepted
**Context:**

Real-time threat detection requires processing events as they occur. Needed a message broker for:
- Decoupling services
- Handling traffic spikes
- Ensuring event processing reliability

**Decision:**
Redis with Redis Streams for event processing:
- **Performance**: Sub-millisecond latency for critical security events
- **Persistence**: Optional persistence for important events
- **Simplicity**: Less complex than Kafka for our scale
- **Pub/Sub**: Built-in publish/subscribe capabilities

**Consequences:**
- **Positive**: Fast event processing, simple operational model
- **Negative**: Single point of failure (mitigated with Redis Cluster)
- **Future**: May need to migrate to Kafka as volume grows

### 7. Team Playbooks

#### On-Call Playbook

**On-Call Schedule:**
- Primary: 24/7 rotation, 1-week shifts
- Secondary: Backup engineer for escalation
- Manager: Available for business decisions

**Escalation Matrix:**
1. **P0 (Critical)**: Page immediately, escalate to manager within 30 minutes
2. **P1 (High)**: Page within 15 minutes, escalate after 2 hours
3. **P2 (Medium)**: Create ticket, address during business hours
4. **P3 (Low)**: Weekly review, batch processing

**Common Alert Responses:**

**Alert: "High Error Rate in auth-service"**
1. Check service logs: `kubectl logs deployment/auth-service -n datakrypt --tail=100`
2. Verify database connectivity
3. Check if it's a deployment issue (recent releases)
4. Scale up if traffic spike: `kubectl scale deployment/auth-service --replicas=5`
5. If persistent, rollback to previous version

**Alert: "Encryption Service Down"**
1. **CRITICAL** - This blocks all new data encryption
2. Check pod status: `kubectl get pods -n datakrypt | grep encryption`
3. Restart pods: `kubectl rollout restart deployment/encryption-service`
4. Verify HSM connectivity: `curl -H "Authorization: Bearer $TOKEN" https://api.datakrypt.com/keys/v1/hsm/status`
5. If HSM issues, activate backup HSM immediately

**Alert: "Suspicious Activity Detected"**
1. Do NOT restart threat-detection-service
2. Investigate the specific threat: Check threat dashboard
3. Verify if it's a real threat or false positive
4. If real threat: Follow incident response procedure
5. Document findings in security channel

#### Development Workflow

**Branch Strategy:**
- `main`: Production-ready code
- `develop`: Integration branch for features
- `feature/*`: Individual feature development
- `hotfix/*`: Emergency production fixes

**Code Review Process:**
1. All code requires 2 approvals
2. Security-sensitive changes require security team review
3. Database migrations require DBA review
4. Performance testing required for core service changes

**Deployment Process:**
1. **Development**: Auto-deploy from `develop` branch
2. **Staging**: Manual promotion with full test suite
3. **Production**: Blue/green deployment with rollback capability

**Testing Requirements:**
- Unit tests: 80% coverage minimum
- Integration tests: All API endpoints
- Security tests: OWASP compliance scanning
- Performance tests: Load testing for core services

### 8. Configuration Management

#### Environment Variables Reference

**auth-service Environment Variables:**

```bash
# Database Configuration
DATABASE_URL=postgresql://user:pass@host:5432/dbname
DATABASE_POOL_SIZE=20
DATABASE_TIMEOUT=30s

# JWT Configuration  
JWT_SECRET=your-256-bit-secret
JWT_EXPIRATION=3600
JWT_REFRESH_EXPIRATION=86400

# Security Settings
BCRYPT_ROUNDS=12
RATE_LIMIT_REQUESTS=100
RATE_LIMIT_WINDOW=60s
MFA_REQUIRED=true

# External Services
REDIS_URL=redis://redis:6379/0
NOTIFICATION_SERVICE_URL=http://notification-service:8006
AUDIT_LOG_ENABLED=true

# Monitoring
METRICS_ENABLED=true
PROMETHEUS_PORT=9090
LOG_LEVEL=INFO
```

**encryption-service Environment Variables:**

```bash
# HSM Configuration
HSM_ENDPOINT=https://hsm.datakrypt.internal
HSM_PARTITION=production
HSM_USERNAME=datakrypt_service
HSM_PASSWORD_SECRET=hsm-credentials

# Key Management
DEFAULT_ALGORITHM=AES-256-GCM
KEY_ROTATION_SCHEDULE=90d
BACKUP_KEY_COUNT=3

# Performance Settings
ENCRYPTION_WORKERS=4
BATCH_SIZE=100
CACHE_TTL=300s

# Compliance
FIPS_MODE=true
AUDIT_ALL_OPERATIONS=true
PCI_DSS_COMPLIANT=true
```

#### Secrets Management Strategy

**Secret Types:**
1. **Database credentials**: Stored in Kubernetes secrets
2. **API keys**: Managed by key-management-service
3. **HSM credentials**: External secret management (HashiCorp Vault)
4. **SSL/TLS certificates**: cert-manager with Let's Encrypt

**Secret Rotation Schedule:**
- Database passwords: Every 90 days
- API keys: Every 60 days
- HSM credentials: Every 180 days
- SSL certificates: Auto-renewal 30 days before expiration

**Access Control:**
- Secrets accessible only to specific service accounts
- Human access requires approval workflow
- All secret access logged and audited

### 9. Performance Optimization Guidelines

#### Database Optimization

**Query Performance:**
- All queries must have appropriate indexes
- Use EXPLAIN ANALYZE for query optimization
- Avoid N+1 queries with proper eager loading
- Implement connection pooling (PgBouncer)

**Common Query Patterns:**

```sql
-- Efficient user lookup with role check
SELECT u.id, u.username, u.role, array_agg(p.permission_name) as permissions
FROM users u
LEFT JOIN user_permissions up ON u.id = up.user_id  
LEFT JOIN permissions p ON up.permission_id = p.id
WHERE u.username = $1 AND u.active = true
GROUP BY u.id, u.username, u.role;

-- Efficient threat analysis retrieval
SELECT t.*, ta.threat_score, ta.severity 
FROM threats t
JOIN threat_analyses ta ON t.analysis_id = ta.id
WHERE ta.created_at >= $1 
  AND ta.severity IN ('high', 'critical')
ORDER BY ta.created_at DESC, ta.threat_score DESC
LIMIT 100;
```

**Index Strategy:**
```sql
-- Auth service indexes
CREATE INDEX idx_users_username ON users(username) WHERE active = true;
CREATE INDEX idx_api_keys_key_hash ON api_keys(key_hash) WHERE active = true;
CREATE INDEX idx_user_sessions_token ON user_sessions(session_token, expires_at);

-- Threat detection indexes  
CREATE INDEX idx_threats_timestamp ON threats(timestamp) WHERE processed = true;
CREATE INDEX idx_threat_analyses_severity_time ON threat_analyses(severity, created_at);
```

#### Caching Strategy

**Redis Caching Layers:**
1. **Session storage**: User sessions and temporary auth tokens
2. **Query cache**: Frequently accessed reference data
3. **Rate limiting**: Track API usage per user/IP
4. **Threat patterns**: Cache common threat detection rules

**Cache Key Patterns:**
```python
# User session
session:{session_token}

# API rate limiting  
rate_limit:user:{user_id}:{window}
rate_limit:ip:{ip_address}:{window}

# Threat rules cache
threat_rules:active
threat_rules:user:{user_id}

# Query cache
query:users:permissions:{user_id}
query:encryption_keys:active
```

**Cache Invalidation:**
- Time-based expiration for most data
- Event-based invalidation for critical updates
- Cache warming for frequently accessed data

### 10. Incident Response Documentation

### 2. Deployment & Operations

**P0 - Critical (Page Immediately)**
- Complete service outage
- Data breach or security compromise
- Payment processing failure
- Customer data corruption

**P1 - High (Page within 15 minutes)**
- Partial service degradation
- Failed authentication for multiple users
- Encryption service errors
- Compliance violation detected

**P2 - Medium (Business hours response)**
- Performance degradation
- Non-critical feature failures
- Monitoring alerts without user impact
- Third-party service issues

**P3 - Low (Weekly review)**
- Documentation updates needed
- Minor configuration drift
- Optimization opportunities
- Enhancement requests

#### Post-Incident Review Template

**Incident:** [Brief description]
**Date:** [YYYY-MM-DD]
**Duration:** [Start time - End time]
**Severity:** [P0/P1/P2/P3]

**Timeline:**
- **HH:MM** - First alert/detection
- **HH:MM** - Investigation started
- **HH:MM** - Root cause identified
- **HH:MM** - Fix implemented
- **HH:MM** - Service restored
- **HH:MM** - Incident closed

**Root Cause:**
[Technical explanation of what went wrong]

**Resolution:**
[What was done to fix the immediate issue]

**Action Items:**
1. [Preventive measure with owner and deadline]
2. [Process improvement with owner and deadline]
3. [Technical debt with owner and deadline]

**Lessons Learned:**
- What went well during the incident response?
- What could have been handled better?
- What monitoring/alerting gaps were identified?

#### Kubernetes Deployment Guide

**Prerequisites:**
- Kubernetes cluster v1.24+
- Helm 3.8+
- kubectl configured with cluster access

**Environment Setup:**

```bash
# Create namespace
kubectl create namespace datakrypt

# Create secrets for database connection
kubectl create secret generic postgres-credentials \
  --from-literal=username=datakrypt_user \
  --from-literal=password=<secure_password> \
  --namespace=datakrypt

# Create secrets for encryption keys
kubectl create secret generic encryption-keys \
  --from-file=master-key.pem \
  --namespace=datakrypt
```

**Deployment Order:**
1. PostgreSQL database
2. Redis cache
3. auth-service
4. key-management-service
5. encryption-service
6. threat-detection-service
7. compliance-service

**Service Deployment Example (auth-service):**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: auth-service
  namespace: datakrypt
spec:
  replicas: 3
  selector:
    matchLabels:
      app: auth-service
  template:
    metadata:
      labels:
        app: auth-service
    spec:
      containers:
      - name: auth-service
        image: datakrypt/auth-service:v1.2.3
        ports:
        - containerPort: 8001
        env:
        - name: DATABASE_URL
          valueFrom:
            secretKeyRef:
              name: postgres-credentials
              key: url
        - name: JWT_SECRET
          valueFrom:
            secretKeyRef:
              name: jwt-secret
              key: secret
        resources:
          limits:
            memory: "512Mi"
            cpu: "500m"
          requests:
            memory: "256Mi"
            cpu: "250m"
        livenessProbe:
          httpGet:
            path: /health
            port: 8001
          initialDelaySeconds: 30
          periodSeconds: 10
        readinessProbe:
          httpGet:
            path: /ready
            port: 8001
          initialDelaySeconds: 5
          periodSeconds: 5
```

#### Database Migration Procedures

**Running Migrations:**

```bash
# Connect to migration pod
kubectl exec -it deployment/auth-service -n datakrypt -- /bin/bash

# Run pending migrations
python manage.py migrate

# Check migration status
python manage.py showmigrations
```

**Migration Rollback Procedure:**

```bash
# Rollback to specific migration
python manage.py migrate auth_service 0005_add_mfa_support

# Rollback all migrations for an app
python manage.py migrate auth_service zero
```

**Emergency Rollback:**

```bash
# Scale down service
kubectl scale deployment auth-service --replicas=0 -n datakrypt

# Restore database backup
pg_restore -h postgres-host -U datakrypt_user -d datakrypt_db backup_20231201.sql

# Scale service back up
kubectl scale deployment auth-service --replicas=3 -n datakrypt
```

### 3. Troubleshooting Guides

#### Common Issues and Solutions

**Issue: auth-service returning 500 errors**

**Symptoms:**
- HTTP 500 responses from /login endpoint
- Error logs showing "Database connection failed"
- Users cannot authenticate

**Diagnosis:**
```bash
# Check service logs
kubectl logs deployment/auth-service -n datakrypt

# Check database connectivity
kubectl exec -it deployment/auth-service -n datakrypt -- \
  python -c "import psycopg2; conn = psycopg2.connect('$DATABASE_URL'); print('Connected')"

# Check secret configuration
kubectl get secret postgres-credentials -n datakrypt -o yaml
```

**Solution:**
1. Verify database credentials are correct
2. Check if database is accepting connections
3. Restart auth-service pods if needed

```bash
kubectl rollout restart deployment/auth-service -n datakrypt
```

**Issue: High memory usage in threat-detection-service**

**Symptoms:**
- Pods being OOMKilled
- Slow response times
- High memory usage in monitoring

**Diagnosis:**
```bash
# Check resource usage
kubectl top pods -n datakrypt

# Check memory metrics
kubectl exec -it deployment/threat-detection-service -n datakrypt -- \
  python -c "import psutil; print(f'Memory: {psutil.virtual_memory().percent}%')"
```

**Solution:**
1. Increase memory limits in deployment
2. Optimize threat detection algorithms
3. Implement data batching

```yaml
resources:
  limits:
    memory: "2Gi"  # Increased from 1Gi
    cpu: "1000m"
  requests:
    memory: "1Gi"
    cpu: "500m"
```

**Issue: Encryption key rotation failing**

**Symptoms:**
- New data cannot be encrypted
- Key rotation job stuck in pending state
- Alerts from key-management-service

**Diagnosis:**
```bash
# Check key rotation job status
kubectl get jobs -n datakrypt

# Check key-management-service logs
kubectl logs deployment/key-management-service -n datakrypt

# List current keys
curl -H "Authorization: Bearer $TOKEN" \
  https://api.datakrypt.com/encryption/v1/keys
```

**Solution:**
1. Manually trigger key rotation
2. Check HSM connectivity
3. Verify key rotation permissions

### 4. Security Procedures

#### Incident Response Runbook

**Severity Levels:**
- **Critical**: Data breach, system compromise
- **High**: Service unavailable, unauthorized access attempt
- **Medium**: Performance degradation, non-critical security alert
- **Low**: Minor configuration issues

**Critical Incident Response:**

1. **Immediate Actions (0-15 minutes)**
    - Notify security team via PagerDuty
    - Isolate affected systems
    - Preserve evidence

2. **Assessment (15-60 minutes)**
    - Determine scope of impact
    - Identify root cause
    - Document initial findings

3. **Containment (1-4 hours)**
    - Block malicious traffic
    - Rotate compromised credentials
    - Apply security patches

4. **Recovery (4-24 hours)**
    - Restore services from clean backups
    - Verify system integrity
    - Resume normal operations

5. **Post-Incident (24-72 hours)**
    - Conduct post-mortem
    - Update security procedures
    - Notify stakeholders

#### API Key Management

**Key Rotation Schedule:**
- Production API keys: Every 90 days
- Development API keys: Every 180 days
- Emergency rotation: Immediately upon compromise

**Rotation Procedure:**
```bash
# Generate new key
curl -X POST https://api.datakrypt.com/auth/v1/api-keys \
  -H "Authorization: Bearer $ADMIN_TOKEN" \
  -d '{"name": "production-key-2024-q1", "permissions": ["encrypt:data", "decrypt:data"]}'

# Update applications with new key
kubectl patch deployment encryption-service -n datakrypt \
  --type='json' \
  -p='[{"op": "replace", "path": "/spec/template/spec/containers/0/env/0/value", "value": "new_api_key"}]'

# Verify new key works
curl -H "Authorization: Bearer $NEW_KEY" \
  https://api.datakrypt.com/encryption/v1/keys

# Deactivate old key
curl -X DELETE https://api.datakrypt.com/auth/v1/api-keys/old_key_id \
  -H "Authorization: Bearer $ADMIN_TOKEN"
```

### 5. Monitoring & Alerting

#### Key Metrics to Monitor

**Service Health:**
- Response time (p95 < 200ms)
- Error rate (< 0.1%)
- Uptime (99.9% SLA)

**Security Metrics:**
- Failed authentication attempts
- Unusual API usage patterns
- Encryption/decryption volume

**Performance Metrics:**
- Memory usage per service
- CPU utilization
- Database connection pool usage

#### Alert Configurations

**Critical Alerts:**
- Service down for > 2 minutes
- Error rate > 1% for > 5 minutes
- Suspected security incident

**Warning Alerts:**
- Response time > 500ms for > 10 minutes
- Memory usage > 80% for > 15 minutes
- API key nearing expiration (< 7 days)
