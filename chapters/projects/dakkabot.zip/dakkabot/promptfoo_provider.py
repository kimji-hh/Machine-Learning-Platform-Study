"""
Promptfoo Provider for DakkaBot
"""

import sys
import os
import json
from typing import Dict, Any

# Add current directory to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dakka_bot_core import dakka_bot_query, dakka_bot_query_full


def call_api(prompt: str, options: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Promptfoo provider interface for DakkaBot

    Args:
        prompt: The adversarial input/query
        options: Provider configuration options
        context: Additional context from Promptfoo

    Returns:
        Dictionary with output and optional error
    """
    try:
        # Use the simple interface by default
        response = dakka_bot_query(prompt)

        return {
            "output": response
        }

    except Exception as e:
        return {
            "output": None,
            "error": str(e)
        }


def call_api_full(prompt: str, options: Dict[str, Any], context: Dict[str, Any]) -> Dict[str, Any]:
    """
    Promptfoo provider interface for DakkaBot with full metadata

    Args:
        prompt: The adversarial input/query
        options: Provider configuration options
        context: Additional context from Promptfoo

    Returns:
        Dictionary with output and optional error
    """
    try:
        # Use the full interface for detailed testing
        result = dakka_bot_query_full(prompt)

        if result.get("error"):
            return {
                "output": None,
                "error": result["error"]
            }

        # Return the response with metadata as JSON
        return {
            "output": json.dumps({
                "response": result["response"],
                "doc_count": result["doc_count"],
                "sources": [s["source"] for s in result["sources"]]
            }, indent=2)
        }

    except Exception as e:
        return {
            "output": None,
            "error": str(e)
        }


# For compatibility with different calling patterns
def main():
    """Command line interface for testing"""
    if len(sys.argv) < 2:
        print("Usage: python promptfoo_provider.py 'your query here'")
        sys.exit(1)

    query = sys.argv[1]
    result = call_api(query, {}, {})

    if result.get("error"):
        print(f"Error: {result['error']}")
    else:
        print(result["output"])


if __name__ == "__main__":
    main()