import os
os.environ['OTEL_SDK_DISABLED'] = 'true'

from guardrails import Guard
from guardrails.hub import CompetitorCheck, GuardrailsPII
from guardrails.types.on_fail import OnFailAction

DATAKRYPT_COMPETITORS = [
    "AWS KMS", "Azure Key Vault", "Google Cloud KMS",
    "HashiCorp Vault", "CyberArk", "Thales", "Venafi"
]

# noinspection PyTypeChecker
input_guard = Guard().use_many(
    CompetitorCheck( DATAKRYPT_COMPETITORS, on_fail=OnFailAction.EXCEPTION),
    GuardrailsPII(entities=["EMAIL_ADDRESS", "CREDIT_CARD"], on_fail=OnFailAction.FIX),
)

def validate_user_inputs(response: str) -> (str, bool):
    """Validate bot response before sending"""
    try:
        result = input_guard.validate(response)
        print(result)
        return result.validated_output, True
    except Exception as e:
        return str(e), False


# print(validate_user_inputs("Compare AWS KMS and CyberArk"))
print(validate_user_inputs("My email is foo@bar.com."))
