"""
DakkaBot - DataKrypt Developer Assistant
Chainlit Application with RAG and LangFuse Observability
"""

import chainlit as cl
from dakka_bot_core import DakkaBotCore
from guardrail_helpers import validate_user_inputs

# Global bot instance
dakka_bot = DakkaBotCore()

@cl.on_chat_start
async def start():
    """Initialize DakkaBot when chat starts"""

    # Show startup message
    await cl.Message(
        content="🚀 **DakkaBot** is starting up...\n\nInitializing DataKrypt knowledge base and AI systems...",
        author="System"
    ).send()

    try:
        # Initialize the bot
        await dakka_bot.initialize()

        # Success message
        await cl.Message(
            content="""✅ **DakkaBot Ready!**

            I'm your DataKrypt developer assistant. I can help you with:

            🔐 **Encryption & Security**
            - Key rotation procedures
            - HSM management
            - Compliance setup

            🛠️ **APIs & Integration**
            - Authentication flows
            - Service configurations
            - Troubleshooting guides

            📊 **Operations & Monitoring**
            - Deployment procedures
            - Performance optimization
            - Incident response

            💼 **Compliance & Governance**
            - HIPAA, PCI DSS, SOX setup
            - Audit procedures
            - Data protection

            **Ask me anything about DataKrypt!** 🤖

            *Example: "How do I rotate encryption keys?" or "What's the HIPAA compliance setup?"*""",
            author="DakkaBot"
        ).send()

    except Exception as e:
        await cl.Message(
            content=f"❌ **Error starting DakkaBot**: {str(e)}\n\nPlease check your configuration and try again.",
            author="System"
        ).send()


@cl.on_message
async def main(message: cl.Message):
    """Handle user messages"""

    if not dakka_bot.initialized:
        await cl.Message(
            content="❌ DakkaBot not properly initialized. Please refresh the page.",
            author="System"
        ).send()
        return

    user_query = message.content

    user_query, is_valid = validate_user_inputs(user_query)
    if not is_valid:
        await cl.Message(
            content=user_query,
            author="User"
        ).send()
        return

    # Show thinking message
    thinking_msg = cl.Message(
        content="🤔 Searching DataKrypt documentation...",
        author="DakkaBot"
    )
    await thinking_msg.send()

    try:
        # Use core logic
        result = await dakka_bot.process_query(user_query)

        if result["error"]:
            await thinking_msg.remove()
            await cl.Message(
                content=f"❌ **Error processing your question**: {result['error']}\n\nPlease try rephrasing your question or check if the DataKrypt documentation is properly loaded.",
                author="DakkaBot"
            ).send()
            return

        # Update thinking message
        thinking_msg.content = f"📚 Found {result['doc_count']} relevant documents. Generating response..."
        await thinking_msg.update()

        # Remove thinking message and send response
        await thinking_msg.remove()

        # Send main response
        await cl.Message(
            content=result["response"],
            author="DakkaBot"
        ).send()

    except Exception as e:
        await thinking_msg.remove()
        await cl.Message(
            content=f"❌ **Unexpected error**: {str(e)}\n\nPlease try again.",
            author="DakkaBot"
        ).send()


if __name__ == "__main__":
    print("Use 'chainlit run chainlit_app.py' to start the application")