import os

from langchain_community.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI
from langfuse import Langfuse
from langfuse.langchain import CallbackHandler

from index import GeminiEmbeddings

embeddings = GeminiEmbeddings()
vector_store = FAISS.load_local("DATA/faiss_index",
                                embeddings=embeddings,
                                allow_dangerous_deserialization=True)

retriever = vector_store.as_retriever()

llm = ChatGoogleGenerativeAI(
    model="gemini-2.5-flash",
    temperature=0.,
    google_api_key=os.environ["GEMINI_API_KEY"],
    convert_system_message_to_human=True  # Gemini compatibility
)

query = "How do I rotate encryption keys?"
docs = retriever.invoke(query)
context = "\n\n".join([doc.page_content for doc in docs])

prompt = f"""
Based on the following DataKrypt documentation, answer the question:

Context: {context}

Question: {query}

Answer:"""

langfuse = Langfuse(
    public_key="pk-lf-83afebcc-8172-4841-b505-f999c3201f84",
    secret_key="sk-lf-0d8e4dd9-b4de-48c4-81df-e4a0826a64df",
    host="http://localhost:3000"
)

langfuse_handler = CallbackHandler()

response = llm.invoke(prompt, config={"callbacks": [langfuse_handler]})

print(response.content)
