import asyncio
import os
from typing import Dict, Any, AsyncGenerator

from langchain_community.vectorstores import FAISS
from langchain_google_genai import ChatGoogleGenerativeAI
from langfuse import Langfuse
from langfuse.langchain import CallbackHandler

from index import GeminiEmbeddings


class DakkaBotCore:
    """Core DakkaBot functionality extracted for testing"""

    def __init__(self):
        self.retriever = None
        self.llm = None
        self.langfuse_handler = None
        self.vector_store = None
        self.initialized = False

    async def initialize(self):
        """Initialize all components"""
        try:
            # Initialize embeddings
            from langchain_google_genai import GoogleGenerativeAIEmbeddings
            embeddings = GeminiEmbeddings()

            # Load FAISS vector store
            self.vector_store = FAISS.load_local(
                "DATA/faiss_index",
                embeddings=embeddings,
                allow_dangerous_deserialization=True
            )

            # Create retriever
            self.retriever = self.vector_store.as_retriever(
                search_kwargs={"k": 5}
            )

            # Initialize Gemini LLM
            self.llm = ChatGoogleGenerativeAI(
                model="gemini-2.5-flash",
                temperature=0.0,
                google_api_key=os.environ["GEMINI_API_KEY"],
                convert_system_message_to_human=True
            )

            # Initialize LangFuse
            langfuse = Langfuse(
                public_key="pk-lf-83afebcc-8172-4841-b505-f999c3201f84",
                secret_key="sk-lf-0d8e4dd9-b4de-48c4-81df-e4a0826a64df",
                host="http://localhost:3000"
            )

            self.langfuse_handler = CallbackHandler()
            self.initialized = True

        except Exception as e:
            raise RuntimeError(f"Failed to initialize DakkaBot: {str(e)}")

    async def process_query(self, query: str) -> Dict[str, Any]:
        """
        Process a user query and return response with metadata

        Args:
            query: User's question

        Returns:
            Dict containing:
            - response: Generated answer
            - sources: List of source documents
            - doc_count: Number of documents found
            - error: Error message if any
        """
        if not self.initialized:
            return {
                "response": None,
                "sources": [],
                "doc_count": 0,
                "error": "DakkaBot not initialized"
            }

        try:
            # Step 1: Retrieve relevant documents
            docs = self.retriever.invoke(query)

            # Step 2: Prepare context
            context = "\n\n".join([
                f"**Document {i + 1}:**\n{doc.page_content}"
                for i, doc in enumerate(docs)
            ])

            # Step 3: Create prompt
            prompt = f"""You are DakkaBot, DataKrypt's expert developer assistant. Based on the provided DataKrypt documentation, answer the user's question accurately and helpfully.

            **Documentation Context:**
            {context}

            **User Question:** {query}

            **Instructions:**
            - Provide accurate, detailed answers based on the documentation
            - Include specific steps, code examples, or configurations when relevant
            - If the question requires multiple services or procedures, explain the complete workflow
            - Use proper formatting for code blocks and lists
            - If you're not sure about something, say so rather than guessing
            - Stay focused on DataKrypt-specific information

            **Answer:**"""

            # Step 4: Generate response
            response = self.llm.invoke(
                prompt,
                config={"callbacks": [self.langfuse_handler]}
            )

            # Step 5: Send Response
            sources = []
            for i, doc in enumerate(docs, 1):
                source_info = {
                    "index": i,
                    "source": doc.metadata.get('source', 'Unknown'),
                    "content_preview": doc.page_content[:150] + "..." if len(
                        doc.page_content) > 150 else doc.page_content,
                    "full_content": doc.page_content
                }
                sources.append(source_info)

            return {
                "response": response.content,
                "sources": sources,
                "doc_count": len(docs),
                "error": None
            }

        except Exception as e:
            return {
                "response": "Sorry! Please try again!",
                "sources": [],
                "doc_count": 0,
                "error": str(e)
            }

    async def process_query_stream(self, query: str) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Process a user query and yield streaming response with metadata

        Args:
            query: User's question

        Yields:
            Dict containing:
            - type: "sources" | "token" | "done" | "error"
            - content: Token content or error message
            - sources: List of source documents (only for "sources" type)
            - doc_count: Number of documents found (only for "sources" type)
        """
        if not self.initialized:
            yield {
                "type": "error",
                "content": "DakkaBot not initialized",
                "sources": [],
                "doc_count": 0
            }
            return

        try:
            # Step 1: Retrieve relevant documents
            docs = self.retriever.invoke(query)

            # Step 2: Yield sources first
            sources = []
            for i, doc in enumerate(docs, 1):
                source_info = {
                    "index": i,
                    "source": doc.metadata.get('source', 'Unknown'),
                    "content_preview": doc.page_content[:150] + "..." if len(
                        doc.page_content) > 150 else doc.page_content,
                    "full_content": doc.page_content
                }
                sources.append(source_info)

            yield {
                "type": "sources",
                "content": None,
                "sources": sources,
                "doc_count": len(docs)
            }

            # Step 3: Prepare context
            context = "\n\n".join([
                f"**Document {i + 1}:**\n{doc.page_content}"
                for i, doc in enumerate(docs)
            ])

            # Step 4: Create prompt
            prompt = f"""You are DakkaBot, DataKrypt's expert developer assistant. Based on the provided DataKrypt documentation, answer the user's question accurately and helpfully.

            **Documentation Context:**
            {context}

            **User Question:** {query}

            **Instructions:**
            - Provide accurate, detailed answers based on the documentation
            - Include specific steps, code examples, or configurations when relevant
            - If the question requires multiple services or procedures, explain the complete workflow
            - Use proper formatting for code blocks and lists
            - If you're not sure about something, say so rather than guessing
            - Stay focused on DataKrypt-specific information

            **Answer:**"""

            # Step 5: Stream response
            async for chunk in self.llm.astream(
                    prompt,
                    config={"callbacks": [self.langfuse_handler]}
            ):
                if chunk.content:
                    yield {
                        "type": "token",
                        "content": chunk.content,
                        "sources": sources,
                        "doc_count": len(docs)
                    }

            # Step 6: Signal completion
            yield {
                "type": "done",
                "content": None,
                "sources": sources,
                "doc_count": len(docs)
            }

        except Exception as e:
            yield {
                "type": "error",
                "content": str(e),
                "sources": [],
                "doc_count": 0
            }


# Global instance for reuse
_dakka_bot = None


async def get_dakka_bot():
    """Get or create DakkaBot instance"""
    global _dakka_bot
    if _dakka_bot is None:
        _dakka_bot = DakkaBotCore()
        await _dakka_bot.initialize()
    return _dakka_bot


# Simple function interface for Promptfoo
def dakka_bot_query(query: str) -> str:
    """
    Simple sync wrapper for DakkaBot query - for Promptfoo testing

    Args:
        query: User question

    Returns:
        Generated response string
    """

    async def _process():
        bot = await get_dakka_bot()
        result = await bot.process_query(query)
        if result["error"]:
            return f"Error: {result['error']}"
        return result["response"]

    return asyncio.run(_process())


# Advanced function interface with full metadata
def dakka_bot_query_full(query: str) -> Dict[str, Any]:
    """
    Full wrapper returning complete response metadata - for detailed testing

    Args:
        query: User question

    Returns:
        Full response dictionary with sources and metadata
    """

    async def _process():
        bot = await get_dakka_bot()
        return await bot.process_query(query)

    return asyncio.run(_process())
