import logging
from dotenv import load_dotenv
from pathlib import Path
from typing import List

# Google AI imports
from google import genai
from google.genai import types

# LangChain imports
from langchain_community.document_loaders import DirectoryLoader, TextLoader
from langchain.embeddings.base import Embeddings
from langchain.schema import Document
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.vectorstores import FAISS
from tqdm import tqdm


# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

load_dotenv()

class GeminiEmbeddings(Embeddings):
    """Simple Gemini embeddings wrapper"""

    def __init__(self):
        self.client = genai.Client()

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """Embed a list of documents"""
        embeddings = []

        for text in tqdm(texts, desc="Embedding documents"):
            result = self.client.models.embed_content(
                model="text-embedding-004",
                contents=text,
                config=types.EmbedContentConfig(task_type="RETRIEVAL_DOCUMENT")
            )
            embeddings.append(result.embeddings[0].values)

        return embeddings

    def embed_query(self, text: str) -> List[float]:
        """Embed a query string"""
        result = self.client.models.embed_content(
            model="text-embedding-004",
            contents=text,
            config=types.EmbedContentConfig(task_type="RETRIEVAL_QUERY")
        )
        return result.embeddings[0].values

def load_documents(data_dir: str) -> List[Document]:
    """Load all Markdown documents"""
    loader = DirectoryLoader(
        data_dir,
        glob="**/*.md",
        loader_cls=TextLoader,
        loader_kwargs={"encoding": "utf-8"}
    )
    documents = loader.load()
    logger.info(f"Loaded {len(documents)} documents")
    return documents

def chunk_documents(documents: List[Document]) -> List[Document]:
    """Chunk documents into smaller pieces"""
    text_splitter = RecursiveCharacterTextSplitter(
        chunk_size=1000,
        chunk_overlap=200,
        separators=["\n## ", "\n### ", "\n\n", "\n", " ", ""]
    )

    chunks = text_splitter.split_documents(documents)
    logger.info(f"Created {len(chunks)} chunks")
    return chunks

def create_faiss_index(chunks: List[Document]) -> FAISS:
    """Create FAISS index from chunks"""
    embeddings = GeminiEmbeddings()

    logger.info("Creating FAISS index with Gemini embeddings...")
    vectorstore = FAISS.from_documents(chunks, embeddings)
    logger.info(f"Created index with {len(chunks)} chunks")

    return vectorstore

def save_index(vectorstore: FAISS, index_path: str = "./DATA/faiss_index"):
    """Save FAISS index to disk"""
    Path(index_path).parent.mkdir(parents=True, exist_ok=True)
    vectorstore.save_local(index_path)
    logger.info(f"Saved index to {index_path}")

def load_index(index_path: str = "./DATA/faiss_index") -> FAISS:
    """Load FAISS index from disk"""
    embeddings = GeminiEmbeddings()
    vectorstore = FAISS.load_local(index_path, embeddings, allow_dangerous_deserialization=True)
    logger.info(f"Loaded index from {index_path}")
    return vectorstore

def main():
    """Main indexing pipeline"""
    data_dir = "./DATA"

    # Step 1: Load documents
    documents = load_documents(data_dir)

    # Step 2: Chunk documents
    chunks = chunk_documents(documents)

    # Step 3: Create FAISS index
    vectorstore = create_faiss_index(chunks)

    # Step 4: Save index
    save_index(vectorstore)

    # Step 5: Quick test
    test_query = "How do I rotate encryption keys?"
    results = vectorstore.similarity_search(test_query, k=3)

    logger.info(f"\nTest query: '{test_query}'")
    logger.info(f"Found {len(results)} results:")
    for i, result in enumerate(results, 1):
        logger.info(f"{i}. {result.page_content[:100]}...")

if __name__ == "__main__":
    main()